# DIGITAL STORE — Telegram Order Bot (Node.js)

Bot Telegram untuk mengurus tempahan item digital secara automatik.
Dibina menggunakan **Telegraf v4** dan **better-sqlite3**.

Boleh dijalankan di:
- VPS / PTE Panel (Node.js 20+)
- Termux (Android)

─────────────────────────────────────────────

## STRUKTUR PROJEK

```
digitalstore-node/
│
├── package.json
├── store.db                ← Database (dicipta automatik)
├── bot.log                  ← Log fail (dicipta automatik)
│
├── assets/
│   └── qrcode.jpg            ← QR Code pembayaran (fail tempatan)
│
└── src/
    ├── main.js              ← Entry point — jalankan fail ini
    ├── config.js            ← Tetapan: BOT_TOKEN, ADMIN_IDS, QR Code
    │
    ├── database/
    │   └── index.js          ← Semua operasi SQLite (items & orders)
    │
    ├── handlers/
    │   ├── user.js           ← /start, klik item, hantar bukti bayaran
    │   └── admin.js          ← /add, /success, /send
    │
    └── utils/
        ├── texts.js          ← Semua templat mesej (aesthetic)
        ├── keyboards.js      ← Pembina inline keyboard
        ├── states.js         ← State sementara untuk /add
        └── logger.js         ← Logger ringkas
```

─────────────────────────────────────────────

## PEMASANGAN (INSTALLATION)

### Di VPS / PTE Panel

```bash
cd digitalstore-node
npm install
```

### Di Termux

```bash
pkg update -y
pkg install -y nodejs python build-essential
cd digitalstore-node
npm install
```

> `better-sqlite3` perlukan `build-essential` (atau `clang`/`make`)
> kerana ia compile native module semasa install. Di Termux,
> pakej `build-essential` biasanya sudah merangkumi keperluan ini.
> Jika masih gagal, cuba `pkg install -y clang make python`.

─────────────────────────────────────────────

## KONFIGURASI

Semua tetapan berada dalam fail **`src/config.js`**.

### A. BOT_TOKEN

1. Buka Telegram, cari **@BotFather**.
2. Hantar `/newbot` dan ikut arahan untuk dapatkan token.
3. Buka `src/config.js`, ganti:

```js
BOT_TOKEN: process.env.BOT_TOKEN || "PASTE_BOT_TOKEN_DISINI",
```

   dengan token sebenar:

```js
BOT_TOKEN: process.env.BOT_TOKEN || "123456789:AAExampleToken",
```

   **ATAU** set environment variable (lebih selamat):

```bash
export BOT_TOKEN="123456789:AAExampleToken"
```

### B. ADMIN_IDS

User ID Telegram admin sudah ditetapkan dalam `src/config.js`:

```js
ADMIN_IDS: [
  7624612389,
],
```

Boleh tambah lebih dari satu admin dengan menambah ID baru
dalam senarai (dipisahkan dengan koma).

> Untuk dapatkan User ID, hantar `/start` kepada **@userinfobot**.

### C. QR CODE PEMBAYARAN

Bot menyokong **2 cara** menghantar QR Code, dengan logik
automatik (fail tempatan dahulu → jika gagal, beralih ke link):

**Pilihan 1 — Fail tempatan (sudah disertakan)**

Fail QR Code anda sudah diletakkan di:

```
assets/qrcode.jpg
```

Bot akan cuba menghantar fail ini dahulu. Boleh gantikan
fail ini dengan QR Code lain pada bila-bila masa.

**Pilihan 2 — Link (fallback automatik, sudah ditetapkan)**

```js
QR_CODE_URL: "https://files.catbox.moe/enl8lt.jpg",
```

Jika `assets/qrcode.jpg` **tidak wujud** atau **gagal dihantar**
(contoh: fail rosak/corrupt), bot akan **automatik** menghantar
QR Code melalui `QR_CODE_URL` sebagai gantinya. Pembeli tidak
akan tertinggal QR Code dalam apa jua keadaan.

─────────────────────────────────────────────

## CARA JALANKAN BOT

```bash
npm start
```

atau:

```bash
node src/main.js
```

Jika berjaya, anda akan lihat log seperti:

```
2026-06-13 03:45:00 | INFO     | main | Bot sedang dimulakan...
2026-06-13 03:45:00 | INFO     | main | Bot berjaya dimulakan dan sedang polling.
```

Bot kini sedia menerima `/start` dari pengguna.

### Jalankan secara latar belakang (VPS)

Disyorkan guna `pm2` supaya bot terus jalan walaupun terminal ditutup:

```bash
npm install -g pm2
pm2 start src/main.js --name digitalstore
pm2 save
pm2 logs digitalstore
```

─────────────────────────────────────────────

## CARA PENGGUNAAN

### Untuk Admin

**1. Tambah Item**

```
/add Panel Unlimited
```

Bot akan balas meminta harga. Balas dengan nombor:

```
25
```

Item terus muncul sebagai butang di menu `/start`.

**2. Sahkan Pembayaran**

Selepas pembeli hantar bukti pembayaran, admin akan
menerima notifikasi. Untuk sahkan:

```
/success 123456789
```

(gantikan `123456789` dengan User ID pembeli)

**3. Hantar Produk**

1. Hantar media/teks yang ingin dihantar kepada pembeli
   (boleh hantar dalam chat mana-mana yang bot ada akses).
2. **Reply** mesej tersebut dengan:

```
/send 123456789
```

Bot akan menyalin kandungan tersebut dan menghantarnya
kepada pembeli. Disokong: text, photo, video, audio,
document, sticker, dan semua jenis media Telegram.

### Untuk Pembeli

1. Taip `/start`.
2. Pilih item dari senarai butang.
3. Bayar mengikut QR Code yang dihantar.
4. Hantar bukti pembayaran (gambar/dokumen/fail).
5. Tunggu pengesahan daripada admin.
6. Produk akan dihantar oleh admin selepas disahkan.

─────────────────────────────────────────────

## SQL SCHEMA

Database (`store.db`) dicipta automatik dengan struktur:

```sql
CREATE TABLE items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    price REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    item_name TEXT NOT NULL,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT NOT NULL
);
```

Status order yang mungkin: `Pending` → `Proof Sent` → `Paid`

─────────────────────────────────────────────

## NOTA PRESTASI (RESPON PANTAS)

- `better-sqlite3` ialah pustaka SQLite **synchronous native**
  (C++ binding) — setiap query siap dalam masa sub-millisecond,
  tanpa overhead callback/promise tambahan.
- `ctx.answerCbQuery()` dipanggil **serta-merta** apabila butang
  ditekan supaya tiada "loading" di sisi pengguna.
- Tiada `setTimeout`/`sleep` atau operasi blocking lain di
  mana-mana bahagian kod.
- Long-polling Telegraf bersifat event-driven sepenuhnya —
  setiap update diproses secara async tanpa menyekat update lain.

─────────────────────────────────────────────

## TROUBLESHOOTING

| Masalah | Penyelesaian |
|---|---|
| `BOT_TOKEN belum ditetapkan` | Edit `src/config.js` atau set env var `BOT_TOKEN` |
| `better-sqlite3` gagal install | Pasang `build-essential` (VPS) atau `build-essential clang make` (Termux) |
| QR Code tidak terhantar | Pastikan `assets/qrcode.jpg` wujud ATAU `QR_CODE_URL` betul |
| Butang item tidak muncul | Pastikan sudah guna `/add` dan masukkan harga |
| `/send` tidak berfungsi | Pastikan ia digunakan sebagai **reply** kepada mesej |
| Bot tidak respon | Semak `bot.log` untuk ralat |
