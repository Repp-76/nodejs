/**
 * src/database/index.js
 * ─────────────────────────────────────────────
 * Modul pengurusan pangkalan data (SQLite).
 *
 * Tanggungjawab modul ini:
 * - Membina struktur jadual (items, orders).
 * - Menyediakan fungsi CRUD untuk item dan order.
 *
 * Menggunakan "better-sqlite3" — pustaka SQLite SYNCHRONOUS
 * yang sangat pantas (operasi native C++, tanpa overhead
 * callback/promise). Untuk skala bot kedai digital (single
 * file SQLite), operasi baca/tulis siap dalam <1ms, jadi
 * tidak menyebabkan sebarang "delay" yang dapat dirasai —
 * malah lebih pantas berbanding driver async biasa kerana
 * tiada overhead event-loop tambahan untuk setiap query.
 */

"use strict";

const Database = require("better-sqlite3");
const { DB_PATH } = require("../config");
const { makeLogger } = require("../utils/logger");

const logger = makeLogger("database");

const db = new Database(DB_PATH);
db.pragma("journal_mode = WAL");

// ─────────────────────────────────────────────
// SQL SCHEMA
// ─────────────────────────────────────────────
const SCHEMA = `
CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    price REAL NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    order_id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT,
    item_name TEXT NOT NULL,
    price REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'Pending',
    created_at TEXT NOT NULL
);
`;

function initDb() {
  db.exec(SCHEMA);
  logger.info(`Database berjaya diinisialisasi (${DB_PATH})`);
}

// ─────────────────────────────────────────────
// OPERASI ITEM
// ─────────────────────────────────────────────

/**
 * Menambah item baru ke dalam database.
 *
 * @returns {boolean} true jika berjaya, false jika nama item sudah wujud.
 */
function addItem(name, price) {
  try {
    const stmt = db.prepare(
      "INSERT INTO items (name, price, created_at) VALUES (?, ?, ?)"
    );
    stmt.run(name, price, new Date().toISOString());
    logger.info(`Item ditambah: ${name} (RM${price.toFixed(2)})`);
    return true;
  } catch (err) {
    if (err.code === "SQLITE_CONSTRAINT_UNIQUE") {
      logger.warn(`Percubaan menambah item yang sudah wujud: ${name}`);
      return false;
    }
    throw err;
  }
}

/**
 * Mendapatkan semua item yang tersedia, disusun mengikut
 * masa ditambah (paling lama dahulu) supaya kedudukan butang
 * di menu /start kekal konsisten.
 *
 * @returns {Array<{id: number, name: string, price: number}>}
 */
function getAllItems() {
  return db.prepare("SELECT id, name, price FROM items ORDER BY id ASC").all();
}

/**
 * Mendapatkan satu item berdasarkan ID.
 *
 * @returns {{id: number, name: string, price: number} | undefined}
 */
function getItemById(itemId) {
  return db
    .prepare("SELECT id, name, price FROM items WHERE id = ?")
    .get(itemId);
}

// ─────────────────────────────────────────────
// OPERASI ORDER
// ─────────────────────────────────────────────

/**
 * Mencipta order baru dengan status 'Pending'.
 *
 * @returns {number} order_id bagi order yang baru dicipta.
 */
function createOrder(userId, username, itemName, price) {
  const stmt = db.prepare(`
    INSERT INTO orders (user_id, username, item_name, price, status, created_at)
    VALUES (?, ?, ?, ?, 'Pending', ?)
  `);
  const result = stmt.run(
    userId,
    username || null,
    itemName,
    price,
    new Date().toISOString()
  );
  const orderId = result.lastInsertRowid;
  logger.info(`Order baru dicipta: #${orderId} oleh user ${userId} (${itemName})`);
  return orderId;
}

/**
 * Mendapatkan order terbaru milik pengguna yang masih berstatus
 * 'Pending' atau 'Proof Sent'. Digunakan untuk mengesan order
 * semasa apabila pembeli menghantar bukti pembayaran.
 */
function getLatestPendingOrder(userId) {
  return db
    .prepare(`
      SELECT * FROM orders
      WHERE user_id = ? AND status IN ('Pending', 'Proof Sent')
      ORDER BY order_id DESC LIMIT 1
    `)
    .get(userId);
}

/**
 * Mendapatkan order PALING BARU bagi seorang pengguna,
 * tanpa mengira status. Digunakan oleh /success untuk
 * menentukan order mana yang hendak disahkan.
 */
function getLatestOrderForUser(userId) {
  return db
    .prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY order_id DESC LIMIT 1")
    .get(userId);
}

/**
 * Mengemas kini status order (Pending / Proof Sent / Paid).
 */
function updateOrderStatus(orderId, status) {
  db.prepare("UPDATE orders SET status = ? WHERE order_id = ?").run(status, orderId);
  logger.info(`Order #${orderId} dikemaskini ke status: ${status}`);
}

module.exports = {
  initDb,
  addItem,
  getAllItems,
  getItemById,
  createOrder,
  getLatestPendingOrder,
  getLatestOrderForUser,
  updateOrderStatus,
};
