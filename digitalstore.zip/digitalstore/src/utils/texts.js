/**
 * src/utils/texts.js
 * ─────────────────────────────────────────────
 * Templat semua mesej yang dipaparkan oleh bot.
 *
 * Pendekatan reka bentuk:
 * - Tanpa emoji.
 * - Gunakan simbol unicode (box-drawing, bullet) untuk kesan
 *   "premium / system" yang kemas.
 * - Pembentukan dipisahkan dari logik handler supaya senang
 *   diubah suai oleh pemilik bot pada bila-bila masa tanpa
 *   menyentuh fail handler.
 */

"use strict";

const DIVIDER = "━━━━━━━━━━━━━━━━━━━━";

/**
 * Format harga kepada bentuk RM yang kemas.
 * Contoh: 25 -> "RM 25", 19.5 -> "RM 19.50"
 */
function formatPrice(price) {
  if (Number.isInteger(price)) {
    return `RM ${price}`;
  }
  return `RM ${price.toFixed(2)}`;
}

function welcomeText(fullName, username, userId) {
  const uname = username ? `@${username}` : "Tidak ditetapkan";
  return (
    `${DIVIDER}\n` +
    `「 DIGITAL STORE 」\n` +
    `${DIVIDER}\n\n` +
    `Selamat datang, ${fullName}.\n\n` +
    `Sistem tempahan automatik ini membolehkan anda\n` +
    `membuat tempahan produk digital dengan pantas\n` +
    `dan selamat.\n\n` +
    `┆ Username  :  ${uname}\n` +
    `┆ User ID   :  ${userId}\n\n` +
    `Sila pilih item yang tersedia di bawah.\n\n` +
    `${DIVIDER}`
  );
}

function noItemsText() {
  return (
    `${DIVIDER}\n` +
    `「 DIGITAL STORE 」\n` +
    `${DIVIDER}\n\n` +
    `Tiada item tersedia pada masa ini.\n\n` +
    `Sila semak semula tidak lama lagi.\n\n` +
    `${DIVIDER}`
  );
}

function itemButtonLabel(name, price) {
  return `${name}  ·  ${formatPrice(price)}`;
}

function askPriceText(itemName) {
  return (
    `${DIVIDER}\n` +
    `「 TAMBAH ITEM 」\n` +
    `${DIVIDER}\n\n` +
    `Item    :  ${itemName}\n\n` +
    `Sila balas mesej ini dengan harga item\n` +
    `dalam bentuk nombor.\n\n` +
    `Contoh  :  25  atau  19.90\n\n` +
    `${DIVIDER}`
  );
}

function itemAddedText(itemName, price) {
  return (
    `${DIVIDER}\n` +
    `「 ITEM DITAMBAH 」\n` +
    `${DIVIDER}\n\n` +
    `Item    :  ${itemName}\n` +
    `Harga   :  ${formatPrice(price)}\n\n` +
    `Item kini dipaparkan pada menu utama.\n\n` +
    `${DIVIDER}`
  );
}

function itemExistsText(itemName) {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Item "${itemName}" sudah wujud dalam senarai.\n\n` +
    `Sila gunakan nama lain.\n\n` +
    `${DIVIDER}`
  );
}

function invalidPriceText() {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Format harga tidak sah.\n\n` +
    `Sila masukkan nombor sahaja.\n` +
    `Contoh  :  25  atau  19.90\n\n` +
    `${DIVIDER}`
  );
}

function orderPickedText(itemName) {
  return (
    `${DIVIDER}\n` +
    `「 TEMPAHAN DITERIMA 」\n` +
    `${DIVIDER}\n\n` +
    `Item    :  ${itemName}\n\n` +
    `Tempahan anda sedang diproses.\n` +
    `Sila tunggu maklumat pembayaran.\n\n` +
    `${DIVIDER}`
  );
}

function adminNewOrderText(itemName, fullName, username, userId, orderId) {
  const uname = username ? `@${username}` : "Tidak ditetapkan";
  return (
    `${DIVIDER}\n` +
    `「 NEW ORDER 」\n` +
    `${DIVIDER}\n\n` +
    `┆ Order ID  :  #${orderId}\n` +
    `┆ Item      :  ${itemName}\n` +
    `┆ Nama      :  ${fullName}\n` +
    `┆ Username  :  ${uname}\n` +
    `┆ User ID   :  ${userId}\n\n` +
    `${DIVIDER}`
  );
}

function paymentRequiredText(price) {
  return (
    `${DIVIDER}\n` +
    `「 PAYMENT REQUIRED 」\n` +
    `${DIVIDER}\n\n` +
    `Jumlah  :  ${formatPrice(price)}\n\n` +
    `Sila lakukan pembayaran mengikut QR Code\n` +
    `di atas, kemudian hantarkan bukti pembayaran\n` +
    `(gambar / dokumen / fail) di sini.\n\n` +
    `${DIVIDER}`
  );
}

function qrCaptionText(price) {
  return (
    `${DIVIDER}\n` +
    `「 KOD QR PEMBAYARAN 」\n` +
    `${DIVIDER}\n\n` +
    `Jumlah  :  ${formatPrice(price)}\n\n` +
    `Imbas kod QR di atas untuk membuat\n` +
    `pembayaran.\n\n` +
    `${DIVIDER}`
  );
}

function qrLinkFallbackText(price) {
  return (
    `${DIVIDER}\n` +
    `「 KOD QR PEMBAYARAN 」\n` +
    `${DIVIDER}\n\n` +
    `Jumlah     :  ${formatPrice(price)}\n\n` +
    `Sila imbas kod QR melalui pautan\n` +
    `di bawah untuk membuat pembayaran.\n\n` +
    `${DIVIDER}`
  );
}

function noPendingOrderText() {
  return (
    `${DIVIDER}\n` +
    `「 NOTIS 」\n` +
    `${DIVIDER}\n\n` +
    `Tiada tempahan aktif dikesan.\n\n` +
    `Sila pilih item terlebih dahulu melalui /start\n` +
    `sebelum menghantar bukti pembayaran.\n\n` +
    `${DIVIDER}`
  );
}

function proofReceivedBuyerText() {
  return (
    `${DIVIDER}\n` +
    `「 BUKTI DITERIMA 」\n` +
    `${DIVIDER}\n\n` +
    `Bukti pembayaran anda telah diterima\n` +
    `dan kini menunggu pengesahan admin.\n\n` +
    `Sila tunggu sebentar.\n\n` +
    `${DIVIDER}`
  );
}

function adminPaymentReceivedText(itemName, fullName, username, userId, orderId) {
  const uname = username ? `@${username}` : "Tidak ditetapkan";
  return (
    `${DIVIDER}\n` +
    `「 PAYMENT RECEIVED 」\n` +
    `${DIVIDER}\n\n` +
    `┆ Order ID  :  #${orderId}\n` +
    `┆ Item      :  ${itemName}\n` +
    `┆ Nama      :  ${fullName}\n` +
    `┆ Username  :  ${uname}\n` +
    `┆ User ID   :  ${userId}\n\n` +
    `Taip  /success ${userId}  untuk sahkan pembayaran.\n\n` +
    `${DIVIDER}`
  );
}

function paymentVerifiedBuyerText() {
  return (
    `${DIVIDER}\n` +
    `「 PAYMENT VERIFIED 」\n` +
    `${DIVIDER}\n\n` +
    `Pembayaran anda telah berjaya disahkan.\n\n` +
    `Sila tunggu penghantaran produk anda.\n\n` +
    `${DIVIDER}`
  );
}

function successAdminConfirmText(orderId, itemName, userId) {
  return (
    `${DIVIDER}\n` +
    `「 STATUS DIKEMASKINI 」\n` +
    `${DIVIDER}\n\n` +
    `Order ID  :  #${orderId}\n` +
    `Item      :  ${itemName}\n` +
    `User ID   :  ${userId}\n` +
    `Status    :  Paid\n\n` +
    `Pembeli telah dimaklumkan.\n` +
    `Gunakan /send ${userId} untuk hantar produk.\n\n` +
    `${DIVIDER}`
  );
}

function successNoOrderText() {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Tiada tempahan ditemui untuk\n` +
    `pengguna tersebut.\n\n` +
    `${DIVIDER}`
  );
}

function usageSuccessText() {
  return (
    `${DIVIDER}\n` +
    `「 CARA PENGGUNAAN 」\n` +
    `${DIVIDER}\n\n` +
    `/success {user_id}\n\n` +
    `Contoh  :  /success 123456789\n\n` +
    `${DIVIDER}`
  );
}

function usageSendText() {
  return (
    `${DIVIDER}\n` +
    `「 CARA PENGGUNAAN 」\n` +
    `${DIVIDER}\n\n` +
    `1. Hantar media / teks yang ingin dihantar.\n` +
    `2. Reply mesej tersebut dengan:\n\n` +
    `   /send {user_id}\n\n` +
    `Contoh  :  /send 123456789\n\n` +
    `${DIVIDER}`
  );
}

function usageAddText() {
  return (
    `${DIVIDER}\n` +
    `「 CARA PENGGUNAAN 」\n` +
    `${DIVIDER}\n\n` +
    `/add {nama item}\n\n` +
    `Contoh  :  /add Panel Unlimited\n\n` +
    `${DIVIDER}`
  );
}

function replyRequiredText() {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Sila reply mesej yang ingin dihantar\n` +
    `dengan arahan /send {user_id}.\n\n` +
    `${DIVIDER}`
  );
}

function sendSuccessAdminText(userId) {
  return (
    `${DIVIDER}\n` +
    `「 PRODUK DIHANTAR 」\n` +
    `${DIVIDER}\n\n` +
    `Kandungan berjaya dihantar kepada\n` +
    `User ID  :  ${userId}\n\n` +
    `${DIVIDER}`
  );
}

function sendFailedAdminText(userId) {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Gagal menghantar kandungan kepada\n` +
    `User ID  :  ${userId}\n\n` +
    `Pengguna mungkin telah menyekat bot.\n\n` +
    `${DIVIDER}`
  );
}

function invalidUserIdText() {
  return (
    `${DIVIDER}\n` +
    `「 RALAT 」\n` +
    `${DIVIDER}\n\n` +
    `Format User ID tidak sah.\n\n` +
    `Sila masukkan nombor sahaja.\n\n` +
    `${DIVIDER}`
  );
}

function notAdminText() {
  return (
    `${DIVIDER}\n` +
    `「 AKSES DITOLAK 」\n` +
    `${DIVIDER}\n\n` +
    `Arahan ini hanya untuk admin.\n\n` +
    `${DIVIDER}`
  );
}

module.exports = {
  DIVIDER,
  formatPrice,
  welcomeText,
  noItemsText,
  itemButtonLabel,
  askPriceText,
  itemAddedText,
  itemExistsText,
  invalidPriceText,
  orderPickedText,
  adminNewOrderText,
  paymentRequiredText,
  qrCaptionText,
  qrLinkFallbackText,
  noPendingOrderText,
  proofReceivedBuyerText,
  adminPaymentReceivedText,
  paymentVerifiedBuyerText,
  successAdminConfirmText,
  successNoOrderText,
  usageSuccessText,
  usageSendText,
  usageAddText,
  replyRequiredText,
  sendSuccessAdminText,
  sendFailedAdminText,
  invalidUserIdText,
  notAdminText,
};
