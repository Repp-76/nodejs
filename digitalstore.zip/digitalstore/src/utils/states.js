/**
 * src/utils/states.js
 * ─────────────────────────────────────────────
 * State store ringkas, in-memory, untuk mengendalikan
 * perbualan bersiri (multi-step conversation) dengan admin.
 *
 * Digunakan untuk:
 * - Menunggu admin memasukkan harga selepas /add
 *
 * Setiap state dikaitkan dengan adminId (Telegram user id).
 * Memandangkan bilangan admin biasanya sangat kecil, Map
 * in-memory lebih dari cukup dan jauh lebih pantas berbanding
 * menyimpan state di database — tiada I/O langsung.
 */

"use strict";

// adminId -> { step: "waiting_for_price", itemName: string }
const pendingAddItem = new Map();

function setPendingAddItem(adminId, itemName) {
  pendingAddItem.set(adminId, { step: "waiting_for_price", itemName });
}

function getPendingAddItem(adminId) {
  return pendingAddItem.get(adminId);
}

function clearPendingAddItem(adminId) {
  pendingAddItem.delete(adminId);
}

module.exports = {
  setPendingAddItem,
  getPendingAddItem,
  clearPendingAddItem,
};
