/**
 * src/utils/logger.js
 * ─────────────────────────────────────────────
 * Logger ringkas untuk bot.
 *
 * Setiap log dihantar ke dua destinasi:
 * - Konsol (stdout) — untuk pemantauan masa nyata.
 * - Fail log (bot.log) — untuk rujukan/audit kemudian.
 *
 * Sengaja tidak menggunakan pustaka luar supaya bilangan
 * dependency dikekalkan minimum (penting untuk pengguna
 * Termux / VPS PTE yang ringan).
 */

"use strict";

const fs = require("fs");
const path = require("path");
const { LOG_FILE } = require("../config");

function timestamp() {
  return new Date().toISOString().replace("T", " ").replace("Z", "");
}

function writeToFile(line) {
  try {
    fs.appendFileSync(LOG_FILE, line + "\n", "utf-8");
  } catch (err) {
    // Jika gagal tulis fail log, jangan crash bot — papar di konsol sahaja.
    console.error("[logger] Gagal tulis ke fail log:", err.message);
  }
}

function format(level, scope, message) {
  return `${timestamp()} | ${level.padEnd(8)} | ${scope} | ${message}`;
}

function makeLogger(scope) {
  return {
    info(message) {
      const line = format("INFO", scope, message);
      console.log(line);
      writeToFile(line);
    },
    warn(message) {
      const line = format("WARN", scope, message);
      console.warn(line);
      writeToFile(line);
    },
    error(message, err) {
      const detail = err && err.message ? ` :: ${err.message}` : "";
      const line = format("ERROR", scope, `${message}${detail}`);
      console.error(line);
      writeToFile(line);
      if (err && err.stack) {
        writeToFile(err.stack);
      }
    },
  };
}

module.exports = { makeLogger };
