/**
 * src/utils/keyboards.js
 * ─────────────────────────────────────────────
 * Pembina (builder) untuk semua Inline Keyboard yang
 * digunakan oleh bot.
 *
 * Memisahkan logik keyboard daripada handler menjadikan
 * kod lebih kemas dan mudah diubah suai pada masa hadapan
 * (contohnya menambah butang baru tanpa menyentuh fail
 * handler utama).
 */

"use strict";

const { Markup } = require("telegraf");
const { itemButtonLabel } = require("./texts");

/**
 * Membina inline keyboard untuk senarai item.
 *
 * Setiap butang mempunyai callback_data dalam format:
 *     item:{item_id}
 *
 * @param {Array<{id: number, name: string, price: number}>} items
 * @returns {ReturnType<typeof Markup.inlineKeyboard> | null}
 *          Markup inline keyboard, atau null jika senarai kosong.
 */
function buildItemsKeyboard(items) {
  if (!items || items.length === 0) {
    return null;
  }

  const rows = items.map((item) => [
    Markup.button.callback(
      itemButtonLabel(item.name, item.price),
      `item:${item.id}`
    ),
  ]);

  return Markup.inlineKeyboard(rows);
}

module.exports = { buildItemsKeyboard };
