/**
 * src/handlers/admin.js
 * ─────────────────────────────────────────────
 * Handler untuk semua arahan ADMIN:
 *
 * - /add {nama item}      : Menambah item baru (2 langkah: nama -> harga)
 * - /success {user_id}    : Mengesahkan pembayaran pembeli
 * - /send {user_id}       : Menghantar produk/media kepada pembeli (reply)
 *
 * Setiap handler menyemak isAdmin(ctx) — hanya ID dalam
 * config.ADMIN_IDS dibenarkan menggunakannya.
 */

"use strict";

const { Composer } = require("telegraf");

const db = require("../database");
const { ADMIN_IDS } = require("../config");
const texts = require("../utils/texts");
const {
  setPendingAddItem,
  getPendingAddItem,
  clearPendingAddItem,
} = require("../utils/states");
const { makeLogger } = require("../utils/logger");

const logger = makeLogger("admin");

const composer = new Composer();

// ─────────────────────────────────────────────
// Helper: hanya admin
// ─────────────────────────────────────────────
function isAdmin(ctx) {
  return ctx.from && ADMIN_IDS.includes(ctx.from.id);
}

// ─────────────────────────────────────────────
// /add {nama item}  ->  Langkah 1: terima nama item
// ─────────────────────────────────────────────
composer.command("add", async (ctx) => {
  if (!isAdmin(ctx)) {
    await ctx.reply(texts.notAdminText());
    return;
  }

  const itemName = (ctx.payload || "").trim();

  if (!itemName) {
    await ctx.reply(texts.usageAddText());
    return;
  }

  // Simpan nama item, tunggu admin balas dengan harga.
  setPendingAddItem(ctx.from.id, itemName);

  await ctx.reply(texts.askPriceText(itemName));

  logger.info(`Admin ${ctx.from.id} memulakan proses tambah item: ${itemName}`);
});

// ─────────────────────────────────────────────
// /success {user_id}
// ─────────────────────────────────────────────
composer.command("success", async (ctx) => {
  if (!isAdmin(ctx)) {
    await ctx.reply(texts.notAdminText());
    return;
  }

  const args = (ctx.payload || "").trim();

  if (!args) {
    await ctx.reply(texts.usageSuccessText());
    return;
  }

  const targetUserId = Number(args);
  if (!Number.isInteger(targetUserId)) {
    await ctx.reply(texts.invalidUserIdText());
    return;
  }

  const order = db.getLatestOrderForUser(targetUserId);

  if (!order) {
    await ctx.reply(texts.successNoOrderText());
    return;
  }

  db.updateOrderStatus(order.order_id, "Paid");

  // Maklumkan pembeli
  try {
    await ctx.telegram.sendMessage(targetUserId, texts.paymentVerifiedBuyerText());
  } catch (err) {
    logger.error(`Gagal hantar PAYMENT VERIFIED kepada user ${targetUserId}`, err);
  }

  // Sahkan kepada admin
  await ctx.reply(texts.successAdminConfirmText(order.order_id, order.item_name, targetUserId));

  logger.info(
    `Order #${order.order_id} disahkan PAID oleh admin ${ctx.from.id} (pembeli: ${targetUserId})`
  );
});

// ─────────────────────────────────────────────
// /send {user_id}  (mesti reply pada media/teks)
// ─────────────────────────────────────────────
composer.command("send", async (ctx) => {
  if (!isAdmin(ctx)) {
    await ctx.reply(texts.notAdminText());
    return;
  }

  const args = (ctx.payload || "").trim();

  if (!args) {
    await ctx.reply(texts.usageSendText());
    return;
  }

  const targetUserId = Number(args);
  if (!Number.isInteger(targetUserId)) {
    await ctx.reply(texts.invalidUserIdText());
    return;
  }

  const replyMsg = ctx.message.reply_to_message;
  if (!replyMsg) {
    await ctx.reply(texts.replyRequiredText());
    return;
  }

  try {
    await ctx.telegram.copyMessage(targetUserId, ctx.chat.id, replyMsg.message_id);
    await ctx.reply(texts.sendSuccessAdminText(targetUserId));
    logger.info(`Admin ${ctx.from.id} menghantar kandungan kepada user ${targetUserId}`);
  } catch (err) {
    logger.error(`Gagal /send kepada user ${targetUserId}`, err);
    await ctx.reply(texts.sendFailedAdminText(targetUserId));
  }
});

// ─────────────────────────────────────────────
// Langkah 2: terima harga (balasan teks selepas /add)
// ─────────────────────────────────────────────
composer.on("text", async (ctx, next) => {
  if (!isAdmin(ctx)) return next();

  const pending = getPendingAddItem(ctx.from.id);
  if (!pending || pending.step !== "waiting_for_price") {
    return next();
  }

  const rawPrice = (ctx.message.text || "").trim().replace(",", ".");
  const price = Number(rawPrice);

  if (Number.isNaN(price) || price < 0) {
    await ctx.reply(texts.invalidPriceText());
    return;
  }

  const itemName = pending.itemName;
  const success = db.addItem(itemName, price);
  clearPendingAddItem(ctx.from.id);

  if (success) {
    await ctx.reply(texts.itemAddedText(itemName, price));
  } else {
    await ctx.reply(texts.itemExistsText(itemName));
  }
});

module.exports = composer;
