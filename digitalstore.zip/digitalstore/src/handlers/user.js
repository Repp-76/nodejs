/**
 * src/handlers/user.js
 * ─────────────────────────────────────────────
 * Handler untuk semua interaksi PEMBELI (user biasa):
 *
 * - /start            : Memaparkan menu utama (senarai item)
 * - Klik butang item  : Mencipta order, notifikasi admin, hantar QR
 * - Hantar bukti      : Terima gambar/dokumen/fail sebagai bukti bayaran
 *
 * Reka bentuk fokus kepada respon segera (tanpa delay) —
 * setiap mesej dihantar terus tanpa proses tambahan yang
 * tidak perlu, dan database yang digunakan (better-sqlite3)
 * bersifat synchronous-native (sub-millisecond).
 */

"use strict";

const fs = require("fs");
const { Composer } = require("telegraf");

const db = require("../database");
const { ADMIN_IDS, QR_CODE_PATH, QR_CODE_URL } = require("../config");
const texts = require("../utils/texts");
const { buildItemsKeyboard } = require("../utils/keyboards");
const { makeLogger } = require("../utils/logger");

const logger = makeLogger("user");

const composer = new Composer();

// ─────────────────────────────────────────────
// /start
// ─────────────────────────────────────────────
composer.start(async (ctx) => {
  const user = ctx.from;
  const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Pengguna";

  const items = db.getAllItems();
  const text = texts.welcomeText(fullName, user.username, user.id);

  if (items.length > 0) {
    const keyboard = buildItemsKeyboard(items);
    await ctx.reply(text, keyboard);
  } else {
    // Tiada item lagi — papar mesej tanpa button.
    await ctx.reply(text);
  }

  logger.info(`User ${user.id} (${user.username}) menjalankan /start`);
});

// ─────────────────────────────────────────────
// Klik butang item
// ─────────────────────────────────────────────
composer.action(/^item:(\d+)$/, async (ctx) => {
  // Jawab callback dahulu supaya butang tidak "loading" — respon segera.
  await ctx.answerCbQuery();

  const user = ctx.from;
  const itemId = Number(ctx.match[1]);

  const item = db.getItemById(itemId);
  if (!item) {
    await ctx.reply(texts.noItemsText());
    return;
  }

  const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Pengguna";

  // 1) Cipta order di database
  const orderId = db.createOrder(user.id, user.username, item.name, item.price);

  // 2) Beritahu pembeli tempahan telah diterima
  await ctx.reply(texts.orderPickedText(item.name));

  // 3) Notifikasi semua admin tentang order baru
  const adminText = texts.adminNewOrderText(
    item.name,
    fullName,
    user.username,
    user.id,
    orderId
  );

  for (const adminId of ADMIN_IDS) {
    try {
      await ctx.telegram.sendMessage(adminId, adminText);
    } catch (err) {
      logger.error(`Gagal hantar notifikasi NEW ORDER ke admin ${adminId}`, err);
    }
  }

  // 4) Hantar QR Code pembayaran kepada pembeli
  await sendQrCode(ctx, user.id, item.price);

  // 5) Mesej meminta bukti pembayaran
  await ctx.telegram.sendMessage(user.id, texts.paymentRequiredText(item.price));

  logger.info(
    `Order #${orderId} dicipta: user=${user.id} item=${item.name} harga=${item.price}`
  );
});

// ─────────────────────────────────────────────
// Hantar QR Code (fail tempatan -> fallback link)
// ─────────────────────────────────────────────

/**
 * Menghantar QR Code pembayaran kepada pembeli.
 *
 * Susunan keutamaan:
 *     1. Fail tempatan (QR_CODE_PATH) — jika wujud & berjaya dihantar.
 *     2. Jika fail tidak wujud / gagal dihantar -> hantar melalui
 *        QR_CODE_URL sebagai link/imej fallback.
 */
async function sendQrCode(ctx, chatId, price) {
  if (fs.existsSync(QR_CODE_PATH)) {
    try {
      await ctx.telegram.sendPhoto(
        chatId,
        { source: QR_CODE_PATH },
        { caption: texts.qrCaptionText(price) }
      );
      return;
    } catch (err) {
      logger.error(
        "Gagal hantar QR Code (fail tempatan), beralih ke link fallback",
        err
      );
    }
  }

  // Fallback: hantar melalui URL
  try {
    await ctx.telegram.sendPhoto(
      chatId,
      { url: QR_CODE_URL },
      { caption: texts.qrLinkFallbackText(price) }
    );
  } catch (err) {
    // Jika URL bukan imej yang sah, hantar sebagai teks pautan.
    logger.error("Gagal hantar QR Code melalui URL, hantar sebagai teks", err);
    await ctx.telegram.sendMessage(
      chatId,
      `${texts.qrLinkFallbackText(price)}\n\n${QR_CODE_URL}`
    );
  }
}

// ─────────────────────────────────────────────
// Bukti pembayaran (gambar / dokumen / fail)
// ─────────────────────────────────────────────
composer.on(["photo", "document"], async (ctx, next) => {
  const user = ctx.from;

  // Admin tidak dianggap sebagai "pembeli" — lepaskan ke handler lain
  // (cth: admin hantar media untuk disimpan sebelum /send).
  if (ADMIN_IDS.includes(user.id)) {
    return next();
  }

  const order = db.getLatestPendingOrder(user.id);
  if (!order) {
    await ctx.reply(texts.noPendingOrderText());
    return;
  }

  const fullName = [user.first_name, user.last_name].filter(Boolean).join(" ") || "Pengguna";

  // Maklumat untuk admin
  const caption = texts.adminPaymentReceivedText(
    order.item_name,
    fullName,
    user.username,
    user.id,
    order.order_id
  );

  for (const adminId of ADMIN_IDS) {
    try {
      // Salin mesej (gambar/dokumen) terus kepada admin.
      await ctx.copyMessage(adminId);
      await ctx.telegram.sendMessage(adminId, caption);
    } catch (err) {
      logger.error(`Gagal hantar bukti pembayaran ke admin ${adminId}`, err);
    }
  }

  // Kemas kini status order
  db.updateOrderStatus(order.order_id, "Proof Sent");

  // Maklumkan pembeli
  await ctx.reply(texts.proofReceivedBuyerText());

  logger.info(`Bukti pembayaran diterima: order=#${order.order_id} user=${user.id}`);
});

module.exports = composer;
