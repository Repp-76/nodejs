/**
 * src/main.js
 * ─────────────────────────────────────────────
 * Titik masuk (entry point) bot Telegram.
 *
 * Tanggungjawab fail ini:
 * - Setup logging & validasi konfigurasi.
 * - Inisialisasi database.
 * - Cipta instance Telegraf bot.
 * - Daftar semua composer (handlers).
 * - Mulakan polling (long-polling).
 *
 * Untuk menjalankan bot:
 *     node src/main.js
 *     atau
 *     npm start
 *
 * Sesuai dijalankan di:
 * - VPS / PTE panel (Node.js >= 20)
 * - Termux (Android)
 */

"use strict";

const { Telegraf } = require("telegraf");

const { BOT_TOKEN } = require("./config");
const { initDb } = require("./database");
const { makeLogger } = require("./utils/logger");

const adminHandlers = require("./handlers/admin");
const userHandlers = require("./handlers/user");

const logger = makeLogger("main");

async function main() {
  if (!BOT_TOKEN || BOT_TOKEN === "PASTE_BOT_TOKEN_DISINI") {
    logger.error(
      "BOT_TOKEN belum ditetapkan. Sila edit fail src/config.js " +
        "atau set environment variable BOT_TOKEN."
    );
    process.exit(1);
  }

  // Inisialisasi database (cipta jadual jika belum wujud)
  initDb();

  const bot = new Telegraf(BOT_TOKEN);

  // Daftar handler.
  // PENTING: handler admin didaftarkan DAHULU supaya arahan
  // admin (/add, /success, /send) ditangkap dahulu sebelum
  // sebarang handler umum di handler user.
  bot.use(adminHandlers.middleware());
  bot.use(userHandlers.middleware());

  // Tangkap sebarang ralat tanpa menjatuhkan keseluruhan proses bot.
  bot.catch((err, ctx) => {
    logger.error(`Ralat tidak dijangka pada update ${ctx.updateType}`, err);
  });

  logger.info("Bot sedang dimulakan...");

  // Padam webhook (jika ada) supaya long-polling berjalan lancar,
  // dan abaikan update lama semasa bot offline.
  await bot.telegram.deleteWebhook({ drop_pending_updates: true });

  await bot.launch();

  logger.info("Bot berjaya dimulakan dan sedang polling.");

  // Graceful shutdown.
  process.once("SIGINT", () => {
    logger.info("Menerima SIGINT, menghentikan bot...");
    bot.stop("SIGINT");
  });
  process.once("SIGTERM", () => {
    logger.info("Menerima SIGTERM, menghentikan bot...");
    bot.stop("SIGTERM");
  });
}

main().catch((err) => {
  logger.error("Gagal memulakan bot", err);
  process.exit(1);
});
