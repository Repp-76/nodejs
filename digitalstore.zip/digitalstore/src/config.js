/**
 * config.js
 * ─────────────────────────────────────────────
 * Konfigurasi utama bot. Semua nilai sensitif (token, admin id)
 * diletakkan di sini supaya mudah diubah tanpa menyentuh logik bot.
 *
 * PENTING:
 * - Jangan kongsi BOT_TOKEN dengan sesiapa.
 * - ADMIN_IDS mesti dalam bentuk integer (User ID Telegram admin).
 */

"use strict";

const path = require("path");

module.exports = {
  // ─────────────────────────────────────────────
  // TOKEN BOT
  // Dapatkan token dari @BotFather di Telegram
  // ─────────────────────────────────────────────
  BOT_TOKEN: process.env.BOT_TOKEN || "8293625592:AAHSXnU-X2HhXhi45yhC9mCZgksVM1Tr5RE",

  // ─────────────────────────────────────────────
  // ADMIN IDS
  // User ID Telegram admin (boleh lebih dari satu jika perlu)
  // Untuk dapatkan User ID, hantar /start kepada @userinfobot
  // ─────────────────────────────────────────────
  ADMIN_IDS: [
    7624612389,
  ],

  // ─────────────────────────────────────────────
  // QR CODE PEMBAYARAN
  // -----------------------------------------------
  // Pilihan 1 : QR_CODE_PATH
  //   Fail QR Code disertakan dalam folder "assets/".
  //   Bot akan cuba hantar fail ini dahulu.
  //
  // Pilihan 2 : QR_CODE_URL
  //   Link terus ke imej QR (hosting luar). Bot akan guna link
  //   ini sebagai "fallback" jika fail tempatan tidak wujud
  //   atau gagal dihantar.
  //
  // Susunan keutamaan: fail tempatan -> jika gagal -> URL link
  // -----------------------------------------------
  QR_CODE_PATH: path.join(__dirname, "..", "assets", "qrcode.jpg"),
  QR_CODE_URL: "https://files.catbox.moe/enl8lt.jpg",

  // ─────────────────────────────────────────────
  // DATABASE
  // ─────────────────────────────────────────────
  DB_PATH: path.join(__dirname, "..", "store.db"),

  // ─────────────────────────────────────────────
  // LOGGING
  // ─────────────────────────────────────────────
  LOG_FILE: path.join(__dirname, "..", "bot.log"),
};
